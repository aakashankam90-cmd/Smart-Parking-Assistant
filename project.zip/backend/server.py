from fastapi import FastAPI, APIRouter, HTTPException, BackgroundTasks
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone
import asyncio


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class Slot(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    slot_id: str
    status: str  # "available" or "occupied"
    vehicle_number: Optional[str] = None
    end_time: Optional[datetime] = None

class Booking(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    booking_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    slot_id: str
    vehicle_number: str
    user_id: str
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    status: str = "occupied"
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class BookingCreate(BaseModel):
    slot_id: str
    vehicle_number: str
    start_time: datetime
    end_time: datetime
    user_id: str = "user_001"  # Default user for simplicity

# Initialize parking slots
@api_router.post("/initialize-slots")
async def initialize_slots():
    # Check if slots already exist
    existing = await db.slots.count_documents({})
    if existing > 0:
        return {"message": "Slots already initialized", "count": existing}
    
    # Create 20 parking slots
    slots = []
    for i in range(1, 21):
        slot = {
            "slot_id": f"A{i:02d}",
            "status": "available",
            "vehicle_number": None
        }
        slots.append(slot)
    
    await db.slots.insert_many(slots)
    return {"message": "Slots initialized successfully", "count": len(slots)}

# Get all slots
@api_router.get("/slots", response_model=List[Slot])
async def get_slots():
    slots = await db.slots.find({}, {"_id": 0}).to_list(100)
    return slots

# Book a slot
@api_router.post("/book", response_model=Booking)
async def book_slot(booking_input: BookingCreate):
    # Check if slot exists and is available
    slot = await db.slots.find_one({"slot_id": booking_input.slot_id})
    
    if not slot:
        raise HTTPException(status_code=404, detail="Slot not found")
    
    if slot["status"] == "occupied":
        raise HTTPException(status_code=400, detail="Slot is already occupied")
    
    # Validate that end_time is after start_time
    if booking_input.end_time <= booking_input.start_time:
        raise HTTPException(status_code=400, detail="End time must be after start time")
    
    # Create booking
    booking_data = booking_input.model_dump()
    booking_data['status'] = "occupied"
    booking = Booking(**booking_data)
    
    booking_doc = booking.model_dump()
    booking_doc['timestamp'] = booking_doc['timestamp'].isoformat()
    booking_doc['start_time'] = booking_doc['start_time'].isoformat()
    booking_doc['end_time'] = booking_doc['end_time'].isoformat()
    
    await db.bookings.insert_one(booking_doc)
    
    # Update slot status with end_time
    await db.slots.update_one(
        {"slot_id": booking_input.slot_id},
        {"$set": {
            "status": "occupied", 
            "vehicle_number": booking_input.vehicle_number,
            "end_time": booking_input.end_time.isoformat()
        }}
    )
    
    return booking

# Get booking history
@api_router.get("/bookings", response_model=List[Booking])
async def get_bookings(user_id: str = "user_001"):
    bookings = await db.bookings.find({"user_id": user_id}, {"_id": 0}).to_list(100)
    
    # Convert ISO string timestamps back to datetime objects
    for booking in bookings:
        if isinstance(booking['timestamp'], str):
            booking['timestamp'] = datetime.fromisoformat(booking['timestamp'])
        if isinstance(booking.get('start_time'), str):
            booking['start_time'] = datetime.fromisoformat(booking['start_time'])
        if isinstance(booking.get('end_time'), str):
            booking['end_time'] = datetime.fromisoformat(booking['end_time'])
    
    return bookings

# Admin: Manually free a slot
@api_router.post("/free-slot/{slot_id}")
async def free_slot(slot_id: str):
    slot = await db.slots.find_one({"slot_id": slot_id})
    
    if not slot:
        raise HTTPException(status_code=404, detail="Slot not found")
    
    # Update slot to available
    await db.slots.update_one(
        {"slot_id": slot_id},
        {"$set": {"status": "available", "vehicle_number": None, "end_time": None}}
    )
    
    # Update any active bookings for this slot
    await db.bookings.update_many(
        {"slot_id": slot_id, "status": "occupied"},
        {"$set": {"status": "released"}}
    )
    
    return {"message": f"Slot {slot_id} freed successfully"}

# Auto-release expired slots
async def auto_release_expired_slots():
    while True:
        try:
            now = datetime.now(timezone.utc)
            
            # Find slots that are occupied and past their end_time
            slots = await db.slots.find({"status": "occupied"}).to_list(100)
            
            for slot in slots:
                if slot.get('end_time'):
                    end_time = datetime.fromisoformat(slot['end_time']) if isinstance(slot['end_time'], str) else slot['end_time']
                    
                    # Make end_time timezone-aware if it's not
                    if end_time.tzinfo is None:
                        end_time = end_time.replace(tzinfo=timezone.utc)
                    
                    if now >= end_time:
                        # Release the slot
                        await db.slots.update_one(
                            {"slot_id": slot['slot_id']},
                            {"$set": {"status": "available", "vehicle_number": None, "end_time": None}}
                        )
                        
                        # Update booking status
                        await db.bookings.update_many(
                            {"slot_id": slot['slot_id'], "status": "occupied"},
                            {"$set": {"status": "completed"}}
                        )
                        
                        logger.info(f"Auto-released slot {slot['slot_id']}")
            
        except Exception as e:
            logger.error(f"Error in auto-release: {e}")
        
        # Check every 30 seconds
        await asyncio.sleep(30)

@api_router.get("/")
async def root():
    return {"message": "Smart Parking API"}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def startup_event():
    # Start background task for auto-releasing slots
    asyncio.create_task(auto_release_expired_slots())
    logger.info("Started auto-release background task")

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
