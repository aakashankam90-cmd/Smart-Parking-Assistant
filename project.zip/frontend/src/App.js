import { useState, useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Home Page - Parking Slots List
const Home = () => {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchSlots();
  }, []);

  const fetchSlots = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/slots`);
      setSlots(response.data);
    } catch (error) {
      console.error("Error fetching slots:", error);
      toast.error("Failed to load parking slots");
    } finally {
      setLoading(false);
    }
  };

  const initializeSlots = async () => {
    try {
      await axios.post(`${API}/initialize-slots`);
      toast.success("Parking slots initialized");
      fetchSlots();
    } catch (error) {
      console.error("Error initializing slots:", error);
      toast.error("Failed to initialize slots");
    }
  };

  const freeSlot = async (slotId) => {
    try {
      await axios.post(`${API}/free-slot/${slotId}`);
      toast.success(`Slot ${slotId} freed successfully`);
      fetchSlots();
    } catch (error) {
      console.error("Error freeing slot:", error);
      toast.error("Failed to free slot");
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="loading">Loading slots...</div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="page-header">
        <h1 data-testid="home-title">Smart Parking Assistant</h1>
        <p className="subtitle">Real-time parking slot availability</p>
      </div>

      {slots.length === 0 && (
        <div className="empty-state">
          <p>No parking slots available. Initialize the system first.</p>
          <Button data-testid="initialize-slots-btn" onClick={initializeSlots}>Initialize Slots</Button>
        </div>
      )}

      <div className="slots-grid">
        {slots.map((slot) => (
          <div
            key={slot.slot_id}
            data-testid={`slot-${slot.slot_id}`}
            className={`slot-card ${slot.status}`}
          >
            <div className="slot-id">{slot.slot_id}</div>
            <div className={`slot-status ${slot.status}`}>
              {slot.status === "available" ? "Available" : "Occupied"}
            </div>
            {slot.vehicle_number && (
              <div className="vehicle-number">{slot.vehicle_number}</div>
            )}
            {slot.status === "occupied" && slot.end_time && (
              <div className="end-time">
                Until: {new Date(slot.end_time).toLocaleString('en-US', { 
                  month: 'short', 
                  day: 'numeric', 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </div>
            )}
            {slot.status === "occupied" && (
              <Button
                data-testid={`free-slot-${slot.slot_id}`}
                onClick={() => freeSlot(slot.slot_id)}
                variant="destructive"
                size="sm"
                className="free-btn"
              >
                Free Slot
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// Book Slot Page
const BookSlot = () => {
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [vehicleNumber, setVehicleNumber] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchAvailableSlots();
    // Set default start time to current time
    const now = new Date();
    const formattedTime = now.toISOString().slice(0, 16);
    setStartTime(formattedTime);
    
    // Set default end time to 1 hour from now
    const oneHourLater = new Date(now.getTime() + 60 * 60 * 1000);
    const formattedEndTime = oneHourLater.toISOString().slice(0, 16);
    setEndTime(formattedEndTime);
  }, []);

  const fetchAvailableSlots = async () => {
    try {
      const response = await axios.get(`${API}/slots`);
      const available = response.data.filter(slot => slot.status === "available");
      setSlots(available);
    } catch (error) {
      console.error("Error fetching slots:", error);
      toast.error("Failed to load available slots");
    }
  };

  const handleBooking = async (e) => {
    e.preventDefault();
    
    if (!selectedSlot || !vehicleNumber || !startTime || !endTime) {
      toast.error("Please fill all fields");
      return;
    }

    // Validate that end time is after start time
    const start = new Date(startTime);
    const end = new Date(endTime);
    
    if (end <= start) {
      toast.error("End time must be after start time");
      return;
    }

    // Validate that end time is not more than 1 year in the future
    const oneYearFromNow = new Date();
    oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
    
    if (end > oneYearFromNow) {
      toast.error("End time cannot be more than 1 year in the future");
      return;
    }

    try {
      setLoading(true);
      await axios.post(`${API}/book`, {
        slot_id: selectedSlot,
        vehicle_number: vehicleNumber,
        start_time: start.toISOString(),
        end_time: end.toISOString(),
        user_id: "user_001"
      });
      
      toast.success(`Slot ${selectedSlot} booked successfully!`);
      setTimeout(() => {
        navigate("/");
      }, 1500);
    } catch (error) {
      console.error("Error booking slot:", error);
      toast.error(error.response?.data?.detail || "Failed to book slot");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="page-header">
        <h1 data-testid="book-slot-title">Book Parking Slot</h1>
        <p className="subtitle">Select an available slot and enter your vehicle details</p>
      </div>

      <Card className="booking-card">
        <CardHeader>
          <CardTitle>Booking Details</CardTitle>
          <CardDescription>Choose your parking slot</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleBooking} className="booking-form">
            <div className="form-group">
              <Label htmlFor="slot">Select Slot</Label>
              <select
                id="slot"
                data-testid="slot-select"
                value={selectedSlot}
                onChange={(e) => setSelectedSlot(e.target.value)}
                className="select-input"
              >
                <option value="">-- Choose a slot --</option>
                {slots.map((slot) => (
                  <option key={slot.slot_id} value={slot.slot_id}>
                    {slot.slot_id}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <Label htmlFor="vehicle">Vehicle Number</Label>
              <Input
                id="vehicle"
                data-testid="vehicle-input"
                type="text"
                placeholder="e.g., ABC-1234"
                value={vehicleNumber}
                onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
              />
            </div>

            <div className="form-group">
              <Label htmlFor="startTime">Start Time</Label>
              <Input
                id="startTime"
                data-testid="start-time-input"
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>

            <div className="form-group">
              <Label htmlFor="endTime">End Time</Label>
              <Input
                id="endTime"
                data-testid="end-time-input"
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
              <p className="time-hint">Select end time (up to 1 year from now)</p>
            </div>

            <Button 
              data-testid="submit-booking-btn"
              type="submit" 
              disabled={loading}
              className="submit-btn"
            >
              {loading ? "Booking..." : "Book Slot"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

// Booking History Page
const BookingHistory = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/bookings?user_id=user_001`);
      setBookings(response.data);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      toast.error("Failed to load booking history");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="loading">Loading booking history...</div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="page-header">
        <h1 data-testid="history-title">Booking History</h1>
        <p className="subtitle">Your past parking bookings</p>
      </div>

      {bookings.length === 0 ? (
        <div className="empty-state">
          <p>No booking history found.</p>
        </div>
      ) : (
        <div className="bookings-list">
          {bookings.map((booking) => (
            <Card key={booking.booking_id} data-testid={`booking-${booking.booking_id}`} className="booking-item">
              <CardContent className="booking-content">
                <div className="booking-info">
                  <div className="info-row">
                    <span className="label">Slot:</span>
                    <span className="value">{booking.slot_id}</span>
                  </div>
                  <div className="info-row">
                    <span className="label">Vehicle:</span>
                    <span className="value">{booking.vehicle_number}</span>
                  </div>
                  {booking.start_time && (
                    <div className="info-row">
                      <span className="label">Start:</span>
                      <span className="value">
                        {new Date(booking.start_time).toLocaleString()}
                      </span>
                    </div>
                  )}
                  {booking.end_time && (
                    <div className="info-row">
                      <span className="label">End:</span>
                      <span className="value">
                        {new Date(booking.end_time).toLocaleString()}
                      </span>
                    </div>
                  )}
                  <div className="info-row">
                    <span className="label">Status:</span>
                    <span className="value status-badge" data-status={booking.status}>
                      {booking.status}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

// Navigation Component
const Navigation = () => {
  return (
    <nav className="navigation">
      <Link to="/" data-testid="nav-home" className="nav-link">Home</Link>
      <Link to="/book" data-testid="nav-book" className="nav-link">Book Slot</Link>
      <Link to="/history" data-testid="nav-history" className="nav-link">History</Link>
    </nav>
  );
};

function App() {
  return (
    <div className="App">
      <Toaster />
      <BrowserRouter>
        <Navigation />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/book" element={<BookSlot />} />
          <Route path="/history" element={<BookingHistory />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
